package com.entity;

public class Jobs {
	private int id;
	private String title;
	private String description;
	private String category;
	private String location;
	private String status;
	private String pdate;

	public Jobs() {
		super();
		// TODO Auto-generated constructor stub
	}

	public Jobs(String title, String description, String category, String location, String status, String pdate) {
		super();
		this.title = title;
		this.description = description;
		this.category = category;
		this.location = location;
		this.status = status;
		this.pdate = pdate;
	}

	/**
	 * @return the id
	 */
	public int getId() {
		return id;
	}

	/**
	 * @param id the id to set
	 */
	public void setId(int id) {
		this.id = id;
	}

	/**
	 * @return the title
	 */
	public String getTitle() {
		return title;
	}

	/**
	 * @param title the title to set
	 */
	public void setTitle(String title) {
		this.title = title;
	}

	/**
	 * @return the description
	 */
	public String getDescription() {
		return description;
	}

	/**
	 * @param description the description to set
	 */
	public void setDescription(String description) {
		this.description = description;
	}

	/**
	 * @return the category
	 */
	public String getCategory() {
		return category;
	}

	/**
	 * @param category the category to set
	 */
	public void setCategory(String category) {
		this.category = category;
	}

	/**
	 * @return the location
	 */
	public String getLocation() {
		return location;
	}

	/**
	 * @param location the location to set
	 */
	public void setLocation(String location) {
		this.location = location;
	}

	/**
	 * @return the status
	 */
	public String getStatus() {
		return status;
	}

	/**
	 * @param pdate the status to set
	 */
	public void setStatus(String status) {
		this.status = status;
	}

	/**
	 * @return the pdate
	 */
	public String getPdate() {
		return pdate;
	}

	/**
	 * @param pdate the pdate to set
	 */
	public void setPdate(String pdate) {
		this.pdate = pdate;
	}

}
